import java.util.ArrayList;

public class Author extends Person {

    public Author(String name){
        super(name);
    }

    public ArrayList<Book> book = new ArrayList<>(); 
    
    
    
}