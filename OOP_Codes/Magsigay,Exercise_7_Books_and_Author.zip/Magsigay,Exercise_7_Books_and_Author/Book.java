import java.util.ArrayList;

public class Book {
    
    private String title;
    public ArrayList<Author> author = new ArrayList<>();

    public Book(String title) {}
    public void addAuthors(Author author){}
    public String getTitle(){
        return title;
    }
    public String toString(){
        return toString();
    }
}
